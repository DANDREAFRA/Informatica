/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arkanoid;

import javax.swing.JFrame;

/**
 *
 * @author BR3AKPO!NT
 */
public class ARKANOID {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame arkanoid = new JFrame();
        Gameplay gameplay = new Gameplay();
        arkanoid.setBounds(10, 10, 700, 700);
        arkanoid.setTitle("Classic Arkanoid");
        arkanoid.setResizable(false);
        arkanoid.setVisible(true);
        arkanoid.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        arkanoid.add(gameplay);
    }
    
}
